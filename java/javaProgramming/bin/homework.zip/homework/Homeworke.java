package homework;

public class Homeworke {
//	2. 도서의 제목, 저자, 출판사, 가격을 속성으로 가지고 정보를 저장하는 메소드와 정보를 출력하는 메소드를 갖는 도서 클래스를 생성하세요.
	
	String title;
	String name1;
	String info;
	int price;
	
	public Homeworke() {
		
	}
	
	public Homeworke(String title, String name1, String info, int price) {
		this.name1 = name1;
		this.title = title;
		this.info = info;
		this.price = price;
	}

}
