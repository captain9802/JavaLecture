package homework;

public class Homework {
//	1. 학생의 이름, 학번, 학과를 속성으로 가지고 학생의 정보를 저장하는 메소드와 학생의 정보를 출력하는 메소드를 갖는 학생 클래스를 생성하세요.
	
	String name;
	int number;
	String clas;
	
	public Homework() {
		
	}
	public Homework(String name, int number, String cals) {
		this.name = name;
		this.number = number;
		this.clas = cals;
		
	}
	
	
//



}
