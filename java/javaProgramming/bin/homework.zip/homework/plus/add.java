package homework.plus;

public class add {
//	
//	1. 더하기, 빼기 곱하기 나누기를 수행하는 각 클래스
//	Add, Sub, Mul, Div를 만드세요
//
//	이들은 모두 다음 필드와 메서드를 가집니다
//
//	1) int타입의 a, b 필드 : 연산하고자 하는 숫자들
//	2) void setValue(int a, int b) : 매개변수로 필드 초기화
//	3) int calculate(): 해당 목적에 맞는 연산을 실행하고 그 결과를 리턴합니다
	
	int a;
	int b;
	
	
	public void setValue1(int a, int b) {
		this.a = a;
		this.b = b;
						
	}
	
	public int add() {
	return a + b;
	}	
	
	
	

	
}
